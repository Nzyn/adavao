// navigationTypes.ts
export type RootStackParamList = {
  Login: undefined;
  Register: undefined;
  Index: undefined;
};
