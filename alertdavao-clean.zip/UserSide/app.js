import React from "react";
import Navigation from "../UserSide/screens/navigation"; // adjust path if needed

export default function App() {
  return <Navigation />;
}
